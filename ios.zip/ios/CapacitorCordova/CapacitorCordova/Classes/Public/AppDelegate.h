#import <Foundation/Foundation.h>
#import "CDVViewController.h"

@interface AppDelegate : NSObject

@property (nonatomic, strong) CDVViewController* viewController;

@end
