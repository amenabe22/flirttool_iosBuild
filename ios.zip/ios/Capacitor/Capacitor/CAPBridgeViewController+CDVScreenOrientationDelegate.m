#import "CAPBridgeViewController+CDVScreenOrientationDelegate.h"

@implementation CAPBridgeViewController (CDVScreenOrientationDelegate)

@end
