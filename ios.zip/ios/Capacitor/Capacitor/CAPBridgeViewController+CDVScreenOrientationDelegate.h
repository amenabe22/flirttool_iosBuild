#import <Capacitor/Capacitor-Swift.h>

@interface CAPBridgeViewController (CDVScreenOrientationDelegate) <CDVScreenOrientationDelegate>

@end

